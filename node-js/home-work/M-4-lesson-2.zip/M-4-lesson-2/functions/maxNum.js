function maxNumArray(arr) {
    return Math.max(...arr);
}

module.exports = maxNumArray;

