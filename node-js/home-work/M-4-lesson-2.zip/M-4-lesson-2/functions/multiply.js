function multiplyArray(arr) {
    return arr.reduce((acc, num) => acc * num, 1);
}


module.exports = multiplyArray;