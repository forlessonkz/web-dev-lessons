function minNumArray(arr) {
    return Math.min(...arr);
}

module.exports = minNumArray;
