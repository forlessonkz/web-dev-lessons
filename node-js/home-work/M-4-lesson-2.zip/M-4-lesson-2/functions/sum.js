function sumArray(arr) {
    return arr.reduce((acc, num) => acc + num, 0);
}


module.exports = sumArray;